#!/Users/huntaj/dev/pythoncertification/venv/bin/python3.7
print(f"__name__ in extras.py: {__name__}")
import helpers
name = "Austin Hunt"